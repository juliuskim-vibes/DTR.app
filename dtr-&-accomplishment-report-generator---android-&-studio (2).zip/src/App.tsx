import React, { useState, useEffect, useMemo } from 'react';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  FileDown,
  Building2,
  Sparkles,
  Filter,
  CheckCircle2,
  CalendarCheck,
  Plane,
  FileSpreadsheet,
  Camera,
  Edit3,
  Trash2,
  Plus,
  RefreshCw,
  User,
  Eye,
} from 'lucide-react';
import { DtrEntry, DayUiModel, InstitutionalMetadata, MonthlyStats, getEntryPhotos } from './types/dtr';
import { exportAccomplishmentReportDocx, downloadBlob } from './utils/docxExport';
import { generateSampleMonthEntries } from './utils/sampleData';
import { downloadAndroidProjectZip } from './utils/androidCodeFiles';
import { TopBar } from './components/TopBar';
import { DailyEntryModal } from './components/DailyEntryModal';
import { InstitutionalModal } from './components/InstitutionalModal';
import { DocumentPreview } from './components/DocumentPreview';
import { ProfileSection } from './components/ProfileSection';
import { AndroidCodeExplorer } from './components/AndroidCodeExplorer';
import { ArchitectureGuide } from './components/ArchitectureGuide';
import { PhotoManagerModal } from './components/PhotoManagerModal';
import { DocumentVerificationModal } from './components/DocumentVerificationModal';
import {
  loadRecordsFromIndexedDb,
  saveRecordsToIndexedDb,
  safeLocalStorageSet,
  safeLocalStorageGet,
  createLightweightRecordSummary,
} from './utils/storage';

export default function App() {
  // Theme state
  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = safeLocalStorageGet('dtr_theme');
      if (saved) return saved === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      safeLocalStorageSet('dtr_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      safeLocalStorageSet('dtr_theme', 'light');
    }
  }, [isDark]);

  const toggleDark = () => setIsDark((prev) => !prev);

  // Tab navigation: 'generator' | 'preview' | 'profile' | 'code' | 'architecture'
  const [activeTab, setActiveTab] = useState<'generator' | 'preview' | 'profile' | 'code' | 'architecture'>('generator');

  // Selected Year & Month (Defaults to October 2026 as in project specs, or customizable)
  const [currentYear, setCurrentYear] = useState<number>(2026);
  const [currentMonth, setCurrentMonth] = useState<number>(10); // 1-12 (October)

  // Institutional Metadata state with 3-tier signatories
  const [metadata, setMetadata] = useState<InstitutionalMetadata>(() => {
    const saved = safeLocalStorageGet('dtr_metadata');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return {
      employeeName: 'JONATHAN K. LUCAGBO',
      employeePosition: 'Instructor I',
      verifiedByName: 'ENGR. REYNALDO T. VELEZ, M.ENG.',
      verifiedByPosition: 'Department Head, Information Technology',
      approvedByName: 'DR. NEMESIO G. LOAYON',
      approvedByPosition: 'Campus Director',
      agencyOrInstitution: 'North Eastern Mindanao State University',
      campusAddress: 'San Miguel, Surigao del Sur 8301',
      contactNumber: '09463014014',
      website: 'www.nemsu.edu.ph',
    };
  });

  const handleSaveMetadata = (newMeta: InstitutionalMetadata) => {
    setMetadata(newMeta);
    safeLocalStorageSet('dtr_metadata', JSON.stringify(newMeta));
  };

  // Persisted DTR records (simulating Room Database via IndexedDB + resilient fallback)
  const [dtrRecords, setDtrRecords] = useState<Record<string, DtrEntry>>(() => {
    // 1. Check if safe storage has cached records
    const saved = safeLocalStorageGet('dtr_records_db');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object' && Object.keys(parsed).length > 0) {
          return parsed;
        }
      } catch (e) {
        console.warn('Could not parse cached records:', e);
      }
    }
    // 2. Initialize with sample institutional data for October 2026
    const initialSamples = generateSampleMonthEntries(2026, 10);
    const map: Record<string, DtrEntry> = {};
    initialSamples.forEach((entry) => {
      map[entry.date] = entry;
    });
    return map;
  });

  // Asynchronous restore from IndexedDB on initial mount
  useEffect(() => {
    let isMounted = true;
    loadRecordsFromIndexedDb().then((indexedDbRecords) => {
      if (isMounted && indexedDbRecords && Object.keys(indexedDbRecords).length > 0) {
        setDtrRecords(indexedDbRecords);
      }
    }).catch((err) => {
      console.warn('IndexedDB initial load error:', err);
    });
    return () => {
      isMounted = false;
    };
  }, []);

  // Safe background persistence to IndexedDB and localStorage
  useEffect(() => {
    // 1. Persist full record set (including photos) in IndexedDB (virtually unlimited quota)
    saveRecordsToIndexedDb(dtrRecords).catch((e) => {
      console.warn('Failed saving to IndexedDB:', e);
    });

    // 2. Attempt safe localStorage write (wrapped in try/catch)
    // If photos make it too large for localStorage's 5MB limit, safeLocalStorageSet
    // will catch QuotaExceededError and keep the light text summary safe
    const json = JSON.stringify(dtrRecords);
    const success = safeLocalStorageSet('dtr_records_db', json);
    if (!success) {
      // Fallback: save text-only lightweight summary in localStorage
      const lightJson = createLightweightRecordSummary(dtrRecords);
      safeLocalStorageSet('dtr_records_summary', lightJson);
    }
  }, [dtrRecords]);

  // Filtering: 'All' | 'Weekdays' | 'Accomplished' | 'Leave' | 'Official Travel' | 'Photos'
  const [filter, setFilter] = useState<string>('All');

  // Modals state
  const [editingDay, setEditingDay] = useState<DayUiModel | null>(null);
  const [isMetadataModalOpen, setIsMetadataModalOpen] = useState<boolean>(false);
  const [isPhotoModalOpen, setIsPhotoModalOpen] = useState<boolean>(false);
  const [isVerificationModalOpen, setIsVerificationModalOpen] = useState<boolean>(false);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  // Month navigation
  const prevMonth = () => {
    if (currentMonth === 1) {
      setCurrentYear((y) => y - 1);
      setCurrentMonth(12);
    } else {
      setCurrentMonth((m) => m - 1);
    }
  };

  const nextMonth = () => {
    if (currentMonth === 12) {
      setCurrentYear((y) => y + 1);
      setCurrentMonth(1);
    } else {
      setCurrentMonth((m) => m + 1);
    }
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December',
  ];
  const monthTitle = `${monthNames[currentMonth - 1]} ${currentYear}`;
  const monthPrefix = `${currentYear}-${String(currentMonth).padStart(2, '0')}`;

  // Compute all days in the selected month (1 to 28/29/30/31)
  const daysList: DayUiModel[] = useMemo(() => {
    const totalDaysInMonth = new Date(currentYear, currentMonth, 0).getDate();
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const fullNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    const list: DayUiModel[] = [];

    for (let day = 1; day <= totalDaysInMonth; day++) {
      const dateObj = new Date(currentYear, currentMonth - 1, day);
      const dayOfWeekIdx = dateObj.getDay();
      const isSat = dayOfWeekIdx === 6;
      const isSun = dayOfWeekIdx === 0;
      const isWeekend = isSat || isSun;

      const dateStr = `${currentYear}-${String(currentMonth).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const savedEntry = dtrRecords[dateStr];

      let activities = savedEntry?.activities || '';
      let remarks = savedEntry?.remarks || '';
      const isLeave = (savedEntry?.status === 'Leave') || activities.toLowerCase().includes('leave');

      const status: DayUiModel['status'] = isWeekend
        ? 'Weekend'
        : isLeave
        ? 'Leave'
        : 'Accomplishment';

      if (isSat && !activities) {
        activities = 'SATURDAY';
        remarks = '';
      } else if (isSun && !activities) {
        activities = 'SUNDAY';
        remarks = '';
      } else if (isLeave) {
        if (!activities) activities = 'Leave';
        remarks = ''; // Leave entry has NO remark
      } else if (!remarks && activities && !isWeekend) {
        remarks = 'Accomplished';
      }

      const entryPhotos = getEntryPhotos(savedEntry || {});

      list.push({
        date: dateStr,
        dayOfMonth: day,
        dayOfWeekName: dayNames[dayOfWeekIdx],
        fullDayName: fullNames[dayOfWeekIdx],
        isWeekend,
        isSaturday: isSat,
        isSunday: isSun,
        activities,
        remarks,
        photoPath: entryPhotos[0] || null,
        photos: entryPhotos,
        status,
        isCustomized: !!savedEntry,
      });
    }

    // Apply filtering
    if (filter === 'Weekdays') return list.filter((d) => !d.isWeekend);
    if (filter === 'Accomplished') return list.filter((d) => d.remarks === 'Accomplished');
    if (filter === 'Ongoing') return list.filter((d) => d.remarks === 'Ongoing');
    if (filter === 'WFH') return list.filter((d) => d.remarks === 'WFH');
    if (filter === 'Official Travel') return list.filter((d) => d.remarks === 'Official Travel');
    if (filter === 'Leave') return list.filter((d) => d.status === 'Leave' || d.activities.toLowerCase().includes('leave'));
    if (filter === 'Photos') return list.filter((d) => (d.photos && d.photos.length > 0) || !!d.photoPath);

    return list;
  }, [currentYear, currentMonth, dtrRecords, filter]);

  // Compute monthly statistics
  const stats: MonthlyStats = useMemo(() => {
    const totalDaysInMonth = new Date(currentYear, currentMonth, 0).getDate();
    let accomplished = 0;
    let ongoing = 0;
    let leaves = 0;
    let weekends = 0;
    let photosCount = 0;

    for (let day = 1; day <= totalDaysInMonth; day++) {
      const dateObj = new Date(currentYear, currentMonth - 1, day);
      const isWk = dateObj.getDay() === 0 || dateObj.getDay() === 6;
      if (isWk) weekends++;

      const dateStr = `${currentYear}-${String(currentMonth).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const entry = dtrRecords[dateStr];

      if (entry) {
        const isLeave = entry.status === 'Leave' || entry.activities.toLowerCase().includes('leave');
        if (isLeave) {
          leaves++;
        } else if (entry.remarks === 'Ongoing') {
          ongoing++;
        } else if (!isWk && (entry.remarks === 'Accomplished' || entry.activities.trim().length > 0)) {
          accomplished++;
        }

        const entryPhotos = getEntryPhotos(entry);
        photosCount += entryPhotos.length;
      }
    }

    return {
      totalDays: totalDaysInMonth,
      accomplishedDays: accomplished,
      ongoingDays: ongoing,
      leaveDays: leaves,
      weekendDays: weekends,
      photosAttached: photosCount,
    };
  }, [currentYear, currentMonth, dtrRecords]);

  // Save an individual day's record (with multiple photos support)
  const handleSaveDailyEntry = (
    dateStr: string,
    dayOfMonth: number,
    activities: string,
    remarks: string,
    status: DayUiModel['status'],
    photoPath: string | null,
    photos?: string[]
  ) => {
    const finalPhotos = photos && photos.length > 0 ? photos : (photoPath ? [photoPath] : []);
    setDtrRecords((prev) => ({
      ...prev,
      [dateStr]: {
        date: dateStr,
        dayOfMonth,
        activities,
        remarks,
        status,
        photoPath: finalPhotos[0] || null,
        photos: finalPhotos,
      },
    }));
    setEditingDay(null);
  };

  // 1-Click Auto-Tag Weekends
  const handleAutoTagAllWeekends = () => {
    const totalDaysInMonth = new Date(currentYear, currentMonth, 0).getDate();
    setDtrRecords((prev) => {
      const updated = { ...prev };
      for (let day = 1; day <= totalDaysInMonth; day++) {
        const dateObj = new Date(currentYear, currentMonth - 1, day);
        const dayOfWeek = dateObj.getDay();
        const dateStr = `${currentYear}-${String(currentMonth).padStart(2, '0')}-${String(day).padStart(2, '0')}`;

        if (dayOfWeek === 6) {
          // Saturday
          if (!updated[dateStr]) {
            updated[dateStr] = {
              date: dateStr,
              dayOfMonth: day,
              activities: 'SATURDAY',
              remarks: '',
              status: 'Weekend',
              photoPath: null,
            };
          }
        } else if (dayOfWeek === 0) {
          // Sunday
          if (!updated[dateStr]) {
            updated[dateStr] = {
              date: dateStr,
              dayOfMonth: day,
              activities: 'SUNDAY',
              remarks: '',
              status: 'Weekend',
              photoPath: null,
            };
          }
        }
      }
      return updated;
    });

    setExportNotice('Weekends automatically tagged as SATURDAY / SUNDAY in Room DB.');
    setTimeout(() => setExportNotice(null), 3500);
  };

  // Fill sample data
  const handleFillSampleData = () => {
    const samples = generateSampleMonthEntries(currentYear, currentMonth);
    setDtrRecords((prev) => {
      const updated = { ...prev };
      samples.forEach((entry) => {
        updated[entry.date] = entry;
      });
      return updated;
    });
    setExportNotice(`Populated realistic institutional activities for ${monthTitle}.`);
    setTimeout(() => setExportNotice(null), 3500);
  };

  // Clear current month
  const handleClearMonth = () => {
    if (confirm(`Clear all logged records for ${monthTitle}?`)) {
      setDtrRecords((prev) => {
        const updated = { ...prev };
        Object.keys(updated).forEach((k) => {
          if (k.startsWith(monthPrefix)) {
            delete updated[k];
          }
        });
        return updated;
      });
    }
  };

  // 1-Click: Delete all attached proof photos for current month (keeps activities and remarks safe)
  const handleDeleteAllMonthPhotos = () => {
    let deletedCount = 0;
    setDtrRecords((prev) => {
      const updated = { ...prev };
      Object.keys(updated).forEach((key) => {
        if (key.startsWith(monthPrefix)) {
          const entry = updated[key];
          const hasPhoto = entry.photoPath || (entry.photos && entry.photos.length > 0);
          if (hasPhoto) {
            deletedCount += getEntryPhotos(entry).length;
            updated[key] = {
              ...entry,
              photoPath: null,
              photos: [],
            };
          }
        }
      });
      return updated;
    });

    setExportNotice(`Purged ${deletedCount} proof photo(s) for ${monthTitle}. All daily logs & remarks preserved.`);
    setTimeout(() => setExportNotice(null), 4000);
  };

  // Delete all photos for a specific day
  const handleDeleteDayPhotos = (dateStr: string) => {
    setDtrRecords((prev) => {
      const entry = prev[dateStr];
      if (!entry) return prev;
      return {
        ...prev,
        [dateStr]: {
          ...entry,
          photoPath: null,
          photos: [],
        },
      };
    });
    setExportNotice(`Photos removed for ${dateStr}.`);
    setTimeout(() => setExportNotice(null), 3000);
  };

  // Delete a specific photo index for a day
  const handleDeleteSpecificPhoto = (dateStr: string, photoIndex: number) => {
    setDtrRecords((prev) => {
      const entry = prev[dateStr];
      if (!entry) return prev;
      const currentPhotos = getEntryPhotos(entry);
      const updatedPhotos = currentPhotos.filter((_, idx) => idx !== photoIndex);
      return {
        ...prev,
        [dateStr]: {
          ...entry,
          photoPath: updatedPhotos[0] || null,
          photos: updatedPhotos,
        },
      };
    });
    setExportNotice(`Removed photo proof #${photoIndex + 1} for ${dateStr}.`);
    setTimeout(() => setExportNotice(null), 3000);
  };

  // Delete photos for multiple selected dates
  const handleDeleteSelectedDates = (dates: string[]) => {
    let count = 0;
    setDtrRecords((prev) => {
      const updated = { ...prev };
      dates.forEach((dateStr) => {
        if (updated[dateStr]) {
          count += getEntryPhotos(updated[dateStr]).length;
          updated[dateStr] = {
            ...updated[dateStr],
            photoPath: null,
            photos: [],
          };
        }
      });
      return updated;
    });
    setExportNotice(`Deleted ${count} proof photo(s) across ${dates.length} selected day(s).`);
    setTimeout(() => setExportNotice(null), 3500);
  };

  // Export to .DOCX
  const handleExportDocx = async () => {
    setIsExporting(true);
    try {
      // Always compute the un-filtered all days list for official submission
      const totalDaysInMonth = new Date(currentYear, currentMonth, 0).getDate();
      const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
      const fullNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

      const fullMonthDays: DayUiModel[] = [];
      for (let day = 1; day <= totalDaysInMonth; day++) {
        const dateObj = new Date(currentYear, currentMonth - 1, day);
        const dayOfWeekIdx = dateObj.getDay();
        const isSat = dayOfWeekIdx === 6;
        const isSun = dayOfWeekIdx === 0;
        const isWeekend = isSat || isSun;
        const dateStr = `${currentYear}-${String(currentMonth).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const saved = dtrRecords[dateStr];

        let activities = saved?.activities || '';
        let remarks = saved?.remarks || '';
        const isLeave = (saved?.status === 'Leave') || activities.toLowerCase().includes('leave');

        const status: DayUiModel['status'] = isWeekend
          ? 'Weekend'
          : isLeave
          ? 'Leave'
          : 'Accomplishment';

        if (isSat && !activities) {
          activities = 'SATURDAY';
          remarks = '';
        } else if (isSun && !activities) {
          activities = 'SUNDAY';
          remarks = '';
        } else if (isLeave) {
          if (!activities) activities = 'Leave';
          remarks = ''; // Leave entry has NO remark
        } else if (!remarks && activities && !isWeekend) {
          remarks = 'Accomplished';
        }

        const entryPhotos = getEntryPhotos(saved || {});

        fullMonthDays.push({
          date: dateStr,
          dayOfMonth: day,
          dayOfWeekName: dayNames[dayOfWeekIdx],
          fullDayName: fullNames[dayOfWeekIdx],
          isWeekend,
          isSaturday: isSat,
          isSunday: isSun,
          activities,
          remarks,
          photoPath: entryPhotos[0] || null,
          photos: entryPhotos,
          status,
          isCustomized: !!saved,
        });
      }

      const blob = await exportAccomplishmentReportDocx(
        monthPrefix,
        monthTitle,
        fullMonthDays,
        metadata
      );

      const sanitizedName = metadata.employeeName.trim().replace(/\s+/g, '_');
      const fileName = `DTR_Accomplishment_Report_${sanitizedName}_${currentYear}_${String(currentMonth).padStart(2, '0')}.docx`;

      downloadBlob(blob, fileName);

      setExportNotice(`Document exported: ${fileName}`);
      setTimeout(() => setExportNotice(null), 4000);
    } catch (err) {
      console.error('Export error:', err);
      setExportNotice('Failed to generate DOCX document. Check console for details.');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      {/* 3-Zone Top Bar Contract */}
      <TopBar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onExportDocx={handleExportDocx}
        onDownloadProjectZip={downloadAndroidProjectZip}
        isExporting={isExporting}
        isDark={isDark}
        toggleDark={toggleDark}
        employeeName={metadata.employeeName}
        onEmployeeNameChange={(name) => handleSaveMetadata({ ...metadata, employeeName: name })}
        onOpenVerificationModal={() => setIsVerificationModalOpen(true)}
      />

      {/* Export / Action Notification Toast */}
      {exportNotice && (
        <div className="sticky top-14 z-30 bg-emerald-600 text-white text-xs font-medium py-2 px-6 flex items-center justify-between shadow-md animate-in slide-in-from-top duration-200">
          <div className="flex items-center gap-2 mx-auto">
            <CheckCircle2 className="w-4 h-4" />
            <span>{exportNotice}</span>
          </div>
          <button
            onClick={() => setExportNotice(null)}
            className="text-white/80 hover:text-white text-sm leading-none ml-4"
          >
            ×
          </button>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6">
        {activeTab === 'generator' && (
          <div className="space-y-6">
            {/* Control Bar: Month Picker & Actions */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs">
              {/* Month Selector */}
              <div className="flex items-center gap-2">
                <button
                  onClick={prevMonth}
                  className="p-1.5 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  title="Previous Month"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>

                <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 rounded-lg">
                  <CalendarIcon className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  <span className="text-sm font-bold text-slate-900 dark:text-white min-w-[140px] text-center">
                    {monthTitle}
                  </span>
                </div>

                <button
                  onClick={nextMonth}
                  className="p-1.5 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  title="Next Month"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              {/* Utility Actions */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleAutoTagAllWeekends}
                  title="Ensure all Saturdays & Sundays have SATURDAY/SUNDAY tag"
                  className="px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <CalendarCheck className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  <span>Auto-Tag Weekends</span>
                </button>

                <button
                  onClick={handleFillSampleData}
                  title="Populate month with realistic educational/project tasks"
                  className="px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <Sparkles className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
                  <span>Fill Sample Data</span>
                </button>

                <button
                  onClick={() => setIsVerificationModalOpen(true)}
                  title="Open read-only 8.5x13 document layout verification modal"
                  className="px-3 py-1.5 text-xs font-semibold text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/70 hover:bg-blue-100 dark:hover:bg-blue-900/60 border border-blue-200 dark:border-blue-800 rounded-lg transition-colors flex items-center gap-1.5 shadow-2xs"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Verify 8.5×13 Layout</span>
                </button>

                <button
                  onClick={() => setIsPhotoModalOpen(true)}
                  title="Manage, selectively delete, or 1-click purge attached photos for this month"
                  className="px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <Camera className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
                  <span>Manage Photos</span>
                  {stats.photosAttached > 0 && (
                    <span className="px-1.5 py-0.5 bg-purple-600 text-white text-[10px] font-mono font-bold rounded-full leading-none">
                      {stats.photosAttached}
                    </span>
                  )}
                </button>

                {stats.photosAttached > 0 && (
                  <button
                    onClick={() => {
                      if (
                        confirm(
                          `Delete ALL ${stats.photosAttached} attached proof photo(s) for ${monthTitle} in one click?\n\nAll daily accomplishment logs, hours, and remarks will be kept intact.`
                        )
                      ) {
                        handleDeleteAllMonthPhotos();
                      }
                    }}
                    title="1-Click: Delete all attached proof photos for this month"
                    className="px-2.5 py-1.5 text-xs font-medium text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/40 hover:bg-red-100 dark:hover:bg-red-900/50 border border-red-200 dark:border-red-900/60 rounded-lg transition-colors flex items-center gap-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span className="hidden lg:inline">Purge Photos</span>
                  </button>
                )}

                <button
                  onClick={() => setActiveTab('profile')}
                  title="Configure Employee, Immediate Head, and Director signatories"
                  className="px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  <User className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                  <span>Profile & Signatories</span>
                </button>

                <button
                  onClick={handleClearMonth}
                  title="Clear all records for this month"
                  className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-red-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Monthly KPI Summary Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs text-center">
              <div className="p-2">
                <span className="block text-xs text-slate-500 dark:text-slate-400">Total Days</span>
                <span className="text-xl font-bold font-mono text-slate-900 dark:text-white">
                  {stats.totalDays}
                </span>
              </div>
              <div className="p-2 border-l border-slate-100 dark:border-slate-800">
                <span className="block text-xs text-slate-500 dark:text-slate-400">Accomplished</span>
                <span className="text-xl font-bold font-mono text-emerald-600 dark:text-emerald-400">
                  {stats.accomplishedDays}
                </span>
              </div>
              <div className="p-2 border-l border-slate-100 dark:border-slate-800">
                <span className="block text-xs text-slate-500 dark:text-slate-400">Ongoing</span>
                <span className="text-xl font-bold font-mono text-blue-600 dark:text-blue-400">
                  {stats.ongoingDays}
                </span>
              </div>
              <div className="p-2 border-l border-slate-100 dark:border-slate-800">
                <span className="block text-xs text-slate-500 dark:text-slate-400">On Leave</span>
                <span className="text-xl font-bold font-mono text-amber-600 dark:text-amber-400">
                  {stats.leaveDays}
                </span>
              </div>
              <div className="p-2 border-l border-slate-100 dark:border-slate-800">
                <span className="block text-xs text-slate-500 dark:text-slate-400">Weekends</span>
                <span className="text-xl font-bold font-mono text-slate-600 dark:text-slate-300">
                  {stats.weekendDays}
                </span>
              </div>
              <div
                onClick={() => setIsPhotoModalOpen(true)}
                className="p-2 border-l border-slate-100 dark:border-slate-800 cursor-pointer hover:bg-purple-50/60 dark:hover:bg-purple-950/30 rounded-r-lg transition-colors group"
                title="Click to view, selectively delete, or 1-click purge photos"
              >
                <span className="block text-xs text-slate-500 dark:text-slate-400 group-hover:text-purple-600 dark:group-hover:text-purple-400">
                  Proof Photos ↗
                </span>
                <span className="text-xl font-bold font-mono text-purple-600 dark:text-purple-400">
                  {stats.photosAttached}
                </span>
              </div>
            </div>

            {/* Interactive Filter Segmented Buttons */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {['All', 'Accomplished', 'Ongoing', 'WFH', 'Official Travel', 'Leave', 'Weekdays', 'Photos'].map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                    filter === f
                      ? 'bg-blue-700 text-white font-semibold dark:bg-blue-600'
                      : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>

            {/* List of Days */}
            <div className="space-y-2.5">
              {daysList.map((day) => {
                const isWk = day.isWeekend;
                const isLeaveEntry = day.status === 'Leave' || day.activities.toLowerCase().includes('leave');

                return (
                  <div
                    key={day.date}
                    onClick={() => setEditingDay(day)}
                    className={`group cursor-pointer p-3.5 sm:p-4 rounded-xl border transition-all ${
                      isWk
                        ? 'bg-slate-100/60 dark:bg-slate-900/40 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-blue-400 dark:hover:border-blue-600 shadow-xs'
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      {/* Day number badge */}
                      <div
                        className={`w-12 h-12 rounded-lg flex flex-col items-center justify-center shrink-0 ${
                          isWk
                            ? 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                            : 'bg-blue-100 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300'
                        }`}
                      >
                        <span className="text-base font-bold font-mono leading-none">
                          {String(day.dayOfMonth).padStart(2, '0')}
                        </span>
                        <span className="text-[10px] uppercase font-semibold mt-0.5">
                          {day.dayOfWeekName}
                        </span>
                      </div>

                      {/* Content column */}
                      <div className="flex-1 min-w-0">
                        {/* Status & Remarks header */}
                        <div className="flex items-center justify-between gap-2 mb-1">
                          <div className="flex items-center gap-2">
                            <span
                              className={`text-[11px] font-semibold uppercase ${
                                isWk && !day.activities
                                  ? 'text-slate-500 dark:text-slate-400'
                                  : isLeaveEntry
                                  ? 'text-amber-700 dark:text-amber-400'
                                  : 'text-blue-700 dark:text-blue-400'
                              }`}
                            >
                              {isWk && !day.activities
                                ? 'WEEKEND'
                                : isLeaveEntry
                                ? 'LEAVE'
                                : 'Accomplishment'}
                            </span>
                            <span className="text-slate-300 dark:text-slate-700 font-mono">·</span>
                            <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">
                              {day.date}
                            </span>
                          </div>

                          {day.remarks && (
                            <span
                              className={`text-[11px] font-bold font-mono px-2 py-0.5 rounded ${
                                day.remarks === 'Accomplished'
                                  ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                                  : day.remarks === 'Ongoing'
                                  ? 'bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300 border border-blue-200 dark:border-blue-800'
                                  : day.remarks === 'WFH'
                                  ? 'bg-purple-100 dark:bg-purple-950/60 text-purple-800 dark:text-purple-300 border border-purple-200 dark:border-purple-800'
                                  : day.remarks === 'Official Travel'
                                  ? 'bg-indigo-100 dark:bg-indigo-950/60 text-indigo-800 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800'
                                  : 'text-slate-700 dark:text-slate-300'
                              }`}
                            >
                              {day.remarks}
                            </span>
                          )}
                        </div>

                        {/* Activities text */}
                        <p
                          className={`text-sm leading-relaxed truncate ${
                            day.activities
                              ? 'text-slate-800 dark:text-slate-200'
                              : isWk
                              ? 'text-slate-400 dark:text-slate-500 italic'
                              : 'text-slate-400 dark:text-slate-500 italic'
                          }`}
                        >
                          {day.activities
                            ? day.activities
                            : isWk
                            ? 'Weekend — No official duty scheduled'
                            : 'No activities logged yet (Click to record)'}
                        </p>
                      </div>

                      {/* Photo Thumbnail if attached (with multiple photos indicator) */}
                      {(() => {
                        const photos = getEntryPhotos(day);
                        if (photos.length === 0) return null;
                        return (
                          <div className="relative shrink-0 w-12 h-12 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 bg-slate-100 dark:bg-slate-900 shadow-2xs">
                            <img
                              src={photos[0]}
                              alt="Attached Proof"
                              className="w-full h-full object-cover"
                            />
                            {photos.length > 1 && (
                              <span className="absolute bottom-0 right-0 px-1 py-0.5 bg-blue-700 text-white text-[9px] font-bold font-mono rounded-tl-xs leading-none shadow-xs">
                                +{photos.length - 1}
                              </span>
                            )}
                          </div>
                        );
                      })()}

                      {/* Edit Arrow */}
                      <div className="shrink-0 text-slate-400 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                        <Edit3 className="w-4 h-4" />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'preview' && (
          <DocumentPreview
            daysList={daysList}
            metadata={metadata}
            monthTitle={monthTitle}
            onExportDocx={handleExportDocx}
            isExporting={isExporting}
            onOpenVerificationModal={() => setIsVerificationModalOpen(true)}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileSection
            metadata={metadata}
            onSave={handleSaveMetadata}
          />
        )}

        {activeTab === 'code' && <AndroidCodeExplorer />}

        {activeTab === 'architecture' && <ArchitectureGuide />}
      </main>

      {/* Floating Action Button (FAB) to edit today */}
      {activeTab === 'generator' && (
        <button
          onClick={() => {
            const today = new Date().getDate();
            const target = daysList.find((d) => d.dayOfMonth === today) || daysList[0];
            setEditingDay(target);
          }}
          className="fixed bottom-6 right-6 z-30 flex items-center gap-2 px-5 py-3 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-full shadow-lg transition-transform hover:scale-105"
        >
          <Plus className="w-4 h-4" />
          <span>Log Entry</span>
        </button>
      )}

      {/* Daily Entry Modal */}
      {editingDay && (
        <DailyEntryModal
          day={editingDay}
          onClose={() => setEditingDay(null)}
          onSave={handleSaveDailyEntry}
        />
      )}

      {/* Institutional Metadata Modal */}
      <InstitutionalModal
        metadata={metadata}
        isOpen={isMetadataModalOpen}
        onClose={() => setIsMetadataModalOpen(false)}
        onSave={handleSaveMetadata}
      />

      {/* Attached Photo Proofs Manager Modal */}
      <PhotoManagerModal
        isOpen={isPhotoModalOpen}
        onClose={() => setIsPhotoModalOpen(false)}
        monthTitle={monthTitle}
        daysList={daysList}
        onDeleteAllMonthPhotos={handleDeleteAllMonthPhotos}
        onDeleteDayPhotos={handleDeleteDayPhotos}
        onDeleteSpecificPhoto={handleDeleteSpecificPhoto}
        onDeleteSelectedDates={handleDeleteSelectedDates}
      />

      {/* 8.5x13 Read-Only Document Verification Modal */}
      <DocumentVerificationModal
        isOpen={isVerificationModalOpen}
        onClose={() => setIsVerificationModalOpen(false)}
        daysList={daysList}
        metadata={metadata}
        monthTitle={monthTitle}
        onExportDocx={handleExportDocx}
        isExporting={isExporting}
      />
    </div>
  );
}
