import React from 'react';
import { FileDown, Printer, Eye, FileText, CheckCircle2 } from 'lucide-react';
import { DayUiModel, InstitutionalMetadata, getEntryPhotos } from '../types/dtr';

interface DocumentPreviewProps {
  daysList: DayUiModel[];
  metadata: InstitutionalMetadata;
  monthTitle: string;
  onExportDocx: () => void;
  isExporting: boolean;
  onOpenVerificationModal?: () => void;
}

export const DocumentPreview: React.FC<DocumentPreviewProps> = ({
  daysList,
  metadata,
  monthTitle,
  onExportDocx,
  isExporting,
  onOpenVerificationModal,
}) => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-12">
      {/* Explicit Print Size Directive for Folio (8.5 x 13 in) */}
      <style>{`
        @media print {
          @page {
            size: 8.5in 13in;
            margin: 0.75in;
          }
          body {
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
          }
        }
      `}</style>

      {/* Top Banner Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs print:hidden">
        <div>
          <div className="flex items-center gap-2">
            <Eye className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <h2 className="text-sm font-bold text-slate-900 dark:text-white">
              Official Institutional Document Preview
            </h2>
            <span className="px-2 py-0.5 text-[10px] font-bold font-mono uppercase bg-blue-100 dark:bg-blue-950 text-blue-800 dark:text-blue-300 rounded border border-blue-200 dark:border-blue-800">
              Folio 8.5 × 13 in
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Arranged on Philippine Folio / Long paper (8.5 × 13 inches) matching the NEMSU institutional format.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <a
            href="/assets/aistudio/DTR_Accomplishment_Report_TEMPLATE_7bb69753.pdf"
            target="_blank"
            rel="noopener noreferrer"
            className="px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
            title="View original template PDF reference"
          >
            <FileText className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            <span>Template PDF</span>
          </a>

          {onOpenVerificationModal && (
            <button
              onClick={onOpenVerificationModal}
              className="px-3 py-1.5 text-xs font-semibold text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950/70 hover:bg-blue-100 dark:hover:bg-blue-900/60 border border-blue-200 dark:border-blue-800 rounded-lg transition-colors flex items-center gap-1.5 shadow-2xs"
              title="Open dedicated full-screen 8.5x13 document verification modal"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Full Verification Modal</span>
            </button>
          )}

          <button
            onClick={handlePrint}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Folio (8.5×13)</span>
          </button>

          <button
            onClick={onExportDocx}
            disabled={isExporting}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors flex items-center gap-1.5 disabled:opacity-60 shadow-xs"
          >
            <FileDown className="w-3.5 h-3.5" />
            <span>{isExporting ? 'Generating...' : 'Export DOCX (8.5×13)'}</span>
          </button>
        </div>
      </div>

      {/* ================= PAGE 1: Days 1 to 23 ================= */}
      <div className="bg-white text-slate-900 p-8 sm:p-12 rounded-xl shadow-lg border border-slate-300 dark:border-slate-700 font-serif print:shadow-none print:border-none print:p-0 print:m-0 print:w-full print:max-w-none [font-family:'Times_New_Roman',Times,serif]">
        {/* Header */}
        <div className="text-center space-y-1 mb-6">
          <p className="text-xs text-slate-800">
            Republic of the Philippines
          </p>
          <h1 className="text-sm font-bold text-slate-950 uppercase tracking-wide">
            {metadata.agencyOrInstitution}
          </h1>
          <div className="pt-2 space-y-0.5">
            <h2 className="text-xs font-bold text-slate-950 tracking-wide uppercase">
              ACCOMPLISHMENT REPORT
            </h2>
            <p className="text-xs font-bold text-slate-900 tracking-wide uppercase">
              MONTH OF {monthTitle.toUpperCase()}
            </p>
          </div>
        </div>

        {/* Sub-Header: Name & Position */}
        <div className="flex justify-between items-center text-xs mb-3 font-serif">
          <div>
            <span className="font-bold text-slate-900">Name: </span>
            <span className="text-slate-800 uppercase font-medium">{metadata.employeeName}</span>
          </div>
          <div>
            <span className="font-bold text-slate-900">Position: </span>
            <span className="text-slate-800 font-medium">{metadata.employeePosition}</span>
          </div>
        </div>

        {/* 3-Column Table: Part 1 (Days 1 to 23) */}
        <div className="border border-slate-950 overflow-hidden">
          <table className="w-full text-xs border-collapse">
            <thead>
              <tr className="bg-[#BDD7EE] text-slate-950 font-bold border-b border-slate-950">
                <th className="py-1 px-2 text-center border-r border-slate-950 w-14 font-bold">
                  Date
                </th>
                <th className="py-1 px-3 text-center border-r border-slate-950 font-bold">
                  Activities
                </th>
                <th className="py-1 px-2 text-center border-slate-950 w-28 font-bold">
                  Remarks
                </th>
              </tr>
            </thead>
            <tbody>
              {daysList.slice(0, 23).map((day) => {
                const isSat = day.isSaturday;
                const isSun = day.isSunday;
                let activitiesText = day.activities.trim();
                let remarksText = day.remarks.trim();
                const isLeave = day.status === 'Leave' || activitiesText.toLowerCase().includes('leave');

                if (isSat) {
                  activitiesText = 'SATURDAY';
                  remarksText = '';
                } else if (isSun) {
                  activitiesText = 'SUNDAY';
                  remarksText = '';
                } else if (isLeave) {
                  if (!activitiesText) activitiesText = 'Leave';
                  remarksText = ''; // Strictly no remark for leave
                } else {
                  if (!remarksText && activitiesText) {
                    remarksText = 'Accomplished';
                  }
                }

                return (
                  <tr
                    key={day.date}
                    className="border-b border-slate-900 last:border-b-0"
                  >
                    <td className="py-1 px-2 text-center border-r border-slate-900 text-xs">
                      <span className={isSat || isSun ? 'font-bold' : ''}>
                        {day.dayOfMonth}
                      </span>
                    </td>
                    <td className="py-1 px-3 text-left border-r border-slate-900 text-slate-900 leading-tight">
                      <span className={isSat || isSun ? 'font-bold' : ''}>
                        {activitiesText}
                      </span>
                    </td>
                    <td className="py-1 px-2 text-center text-slate-900 whitespace-nowrap text-xs">
                      {remarksText}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ================= PAGE 2: Days 24 to end + Signatories ================= */}
      <div className="bg-white text-slate-900 p-8 sm:p-12 rounded-xl shadow-lg border border-slate-300 dark:border-slate-700 font-serif print:shadow-none print:border-none print:p-0 print:m-0 print:w-full print:max-w-none print:break-before-page [font-family:'Times_New_Roman',Times,serif]">
        <div className="text-center text-xs font-semibold text-slate-400 mb-4 print:hidden">
          —— PAGE 2: TABLE CONTINUATION & SIGNATORIES ——
        </div>

        {/* 3-Column Table: Part 2 (Days 24 to End of Month) */}
        <div className="border border-slate-950 overflow-hidden mb-10">
          <table className="w-full text-xs border-collapse">
            <thead>
              <tr className="bg-[#BDD7EE] text-slate-950 font-bold border-b border-slate-950">
                <th className="py-1 px-2 text-center border-r border-slate-950 w-14 font-bold">
                  Date
                </th>
                <th className="py-1 px-3 text-center border-r border-slate-950 font-bold">
                  Activities
                </th>
                <th className="py-1 px-2 text-center border-slate-950 w-28 font-bold">
                  Remarks
                </th>
              </tr>
            </thead>
            <tbody>
              {daysList.slice(23).map((day) => {
                const isSat = day.isSaturday;
                const isSun = day.isSunday;
                let activitiesText = day.activities.trim();
                let remarksText = day.remarks.trim();
                const isLeave = day.status === 'Leave' || activitiesText.toLowerCase().includes('leave');

                if (isSat) {
                  activitiesText = 'SATURDAY';
                  remarksText = '';
                } else if (isSun) {
                  activitiesText = 'SUNDAY';
                  remarksText = '';
                } else if (isLeave) {
                  if (!activitiesText) activitiesText = 'Leave';
                  remarksText = ''; // Strictly no remark for leave
                } else {
                  if (!remarksText && activitiesText) {
                    remarksText = 'Accomplished';
                  }
                }

                return (
                  <tr
                    key={day.date}
                    className="border-b border-slate-900 last:border-b-0"
                  >
                    <td className="py-1 px-2 text-center border-r border-slate-900 text-xs">
                      <span className={isSat || isSun ? 'font-bold' : ''}>
                        {day.dayOfMonth}
                      </span>
                    </td>
                    <td className="py-1 px-3 text-left border-r border-slate-900 text-slate-900 leading-tight">
                      <span className={isSat || isSun ? 'font-bold' : ''}>
                        {activitiesText}
                      </span>
                    </td>
                    <td className="py-1 px-2 text-center text-slate-900 whitespace-nowrap text-xs">
                      {remarksText}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Signatories Section (directly below table matching template page 2) */}
        <div className="grid grid-cols-2 gap-10 pt-2 font-serif">
          {/* Prepared by */}
          <div>
            <p className="text-xs text-slate-800 mb-12">Prepared by:</p>
            <p className="text-xs font-bold text-slate-950 uppercase">
              {metadata.employeeName || '[INPUT NAME]'}
            </p>
            <p className="text-xs text-slate-700">
              {metadata.employeePosition || '[INPUT DESIGNATION]'}
            </p>
          </div>

          {/* Verified by (Immediate Head) */}
          <div>
            <p className="text-xs text-slate-800 mb-12">Verified by:</p>
            <p className="text-xs font-bold text-slate-950 uppercase">
              {metadata.verifiedByName || '[INPUT NAME]'}
            </p>
            <p className="text-xs text-slate-700">
              {metadata.verifiedByPosition || '[INPUT DESIGNATION]'}
            </p>
          </div>
        </div>

        {/* Center Bottom: Approved by (Director) */}
        <div className="flex flex-col items-center justify-center text-center mt-14 font-serif">
          <p className="text-xs text-slate-800 mb-12">Approved by:</p>
          <p className="text-xs font-bold text-slate-950 uppercase">
            {metadata.approvedByName || '[INPUT NAME]'}
          </p>
          <p className="text-xs text-slate-700">
            {metadata.approvedByPosition || '[INPUT DESIGNATION]'}
          </p>
        </div>
      </div>

      {/* ================= ATTACHMENTS FOR VERIFICATION (1 Dedicated Page Per Photo) ================= */}
      {(() => {
        const photoItems: Array<{
          date: string;
          dayOfMonth: number;
          fullDayName: string;
          activities: string;
          status: string;
          photoUrl: string;
          photoIndex: number;
          totalForDay: number;
        }> = [];

        daysList.forEach((day) => {
          const photos = getEntryPhotos(day);
          photos.forEach((photoUrl, photoIndex) => {
            photoItems.push({
              date: day.date,
              dayOfMonth: day.dayOfMonth,
              fullDayName: day.fullDayName,
              activities: day.activities,
              status: day.status,
              photoUrl,
              photoIndex,
              totalForDay: photos.length,
            });
          });
        });

        if (photoItems.length === 0) return null;

        return (
          <div className="space-y-8">
            {photoItems.map((item, globalIdx) => (
              <div
                key={`${item.date}-${item.photoIndex}-${globalIdx}`}
                className="bg-white text-slate-900 p-8 sm:p-12 rounded-xl shadow-lg border border-slate-300 dark:border-slate-700 font-serif print:shadow-none print:border-none print:p-0 print:m-0 print:w-full print:max-w-none print:break-before-page [font-family:'Times_New_Roman',Times,serif]"
              >
                {/* Print/Preview Page Indicator */}
                <div className="text-center text-xs font-semibold text-slate-400 mb-6 print:hidden">
                  —— PAGE {globalIdx + 3}: ATTACHMENT {globalIdx + 1} OF {photoItems.length} ——
                </div>

                {/* Header matching template */}
                <div className="text-center mb-6">
                  <h2 className="text-sm font-bold text-slate-950 uppercase tracking-wide">
                    ATTACHMENTS FOR VERIFICATION
                  </h2>
                </div>

                {/* Inline Date & Activity line matching template */}
                <div className="mb-6 text-xs text-slate-900 leading-relaxed">
                  <span className="font-bold">Date: </span>
                  <span>
                    {item.date} ({item.fullDayName.toUpperCase()})
                    {item.totalForDay > 1 ? ` (Photo ${item.photoIndex + 1} of ${item.totalForDay})` : ''}
                  </span>
                  <span className="mx-2 font-bold">   Activity: </span>
                  <span>{item.activities || 'Official duty logged'}</span>
                </div>

                {/* Clear and Big Centered Photo Frame */}
                <div className="w-full h-[520px] sm:h-[600px] rounded-sm border border-slate-400 bg-slate-950 flex items-center justify-center overflow-hidden p-3 shadow-xs">
                  <img
                    src={item.photoUrl}
                    alt={`Attachment for ${item.date}`}
                    className="max-h-full max-w-full w-auto h-auto object-contain rounded-xs"
                  />
                </div>
              </div>
            ))}
          </div>
        );
      })()}
    </div>
  );
};
