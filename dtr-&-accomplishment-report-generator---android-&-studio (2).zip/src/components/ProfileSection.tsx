import React, { useState } from 'react';
import { User, CheckCircle2, Building, ShieldCheck, Award, RotateCcw, Save } from 'lucide-react';
import { InstitutionalMetadata } from '../types/dtr';

interface ProfileSectionProps {
  metadata: InstitutionalMetadata;
  onSave: (metadata: InstitutionalMetadata) => void;
}

export const ProfileSection: React.FC<ProfileSectionProps> = ({ metadata, onSave }) => {
  const [formData, setFormData] = useState<InstitutionalMetadata>(metadata);
  const [saveNotice, setSaveNotice] = useState<boolean>(false);

  const handleChange = (field: keyof InstitutionalMetadata, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    onSave(formData);
    setSaveNotice(true);
    setTimeout(() => setSaveNotice(false), 3000);
  };

  const handleResetDefaults = () => {
    const defaults: InstitutionalMetadata = {
      employeeName: 'JONATHAN K. LUCAGBO',
      employeePosition: 'Instructor I',
      verifiedByName: 'ENGR. REYNALDO T. VELEZ, M.ENG.',
      verifiedByPosition: 'Department Head, Information Technology',
      approvedByName: 'DR. NEMESIO G. LOAYON',
      approvedByPosition: 'Campus Director',
      agencyOrInstitution: 'North Eastern Mindanao State University',
      campusAddress: 'San Miguel, Surigao del Sur 8301',
      contactNumber: '09463014014',
      website: 'www.nemsu.edu.ph',
    };
    setFormData(defaults);
    onSave(defaults);
    setSaveNotice(true);
    setTimeout(() => setSaveNotice(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <User className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Profile & Signatories Configuration
            </h2>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Configure your employee profile and institutional signatories (Immediate Head & Director) for the Accomplishment Report table.
          </p>
          <p className="text-[11px] text-blue-600 dark:text-blue-400 font-medium mt-0.5">
            Note: Signatures appear on the official report table. Dedicated attachment pages are kept clean with photos only.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="px-3 py-1.5 text-xs font-medium text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>NEMSU Defaults</span>
          </button>

          <button
            type="button"
            onClick={handleSave}
            className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Profile</span>
          </button>
        </div>
      </div>

      {saveNotice && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs font-medium text-emerald-800 dark:text-emerald-200 flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          <span>Profile and signatories saved successfully! All report outputs updated.</span>
        </div>
      )}

      {/* Grid of Profile Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Card 1: Employee (Prepared by) */}
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2.5">
            <User className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span>1. Your Employee Profile (Prepared by)</span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Your Full Name
              </label>
              <input
                type="text"
                value={formData.employeeName}
                onChange={(e) => handleChange('employeeName', e.target.value)}
                placeholder="e.g. JONATHAN K. LUCAGBO"
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none uppercase font-semibold text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Your Position / Designation
              </label>
              <input
                type="text"
                value={formData.employeePosition}
                onChange={(e) => handleChange('employeePosition', e.target.value)}
                placeholder="e.g. Instructor I"
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white"
              />
            </div>
          </div>
        </div>

        {/* Card 2: Immediate Head (Verified by) */}
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>2. Immediate Head (Verified by)</span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Immediate Head Name
              </label>
              <input
                type="text"
                value={formData.verifiedByName}
                onChange={(e) => handleChange('verifiedByName', e.target.value)}
                placeholder="e.g. ENGR. REYNALDO T. VELEZ, M.ENG."
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none uppercase font-semibold text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Immediate Head Position / Designation
              </label>
              <input
                type="text"
                value={formData.verifiedByPosition}
                onChange={(e) => handleChange('verifiedByPosition', e.target.value)}
                placeholder="e.g. Department Head, Information Technology"
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white"
              />
            </div>
          </div>
        </div>

        {/* Card 3: Director (Approved by) */}
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2.5">
            <Award className="w-4 h-4 text-purple-600 dark:text-purple-400" />
            <span>3. Campus Director / Head of Agency (Approved by)</span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Director / Executive Name
              </label>
              <input
                type="text"
                value={formData.approvedByName}
                onChange={(e) => handleChange('approvedByName', e.target.value)}
                placeholder="e.g. DR. NEMESIO G. LOAYON"
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none uppercase font-semibold text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Director Position / Designation
              </label>
              <input
                type="text"
                value={formData.approvedByPosition}
                onChange={(e) => handleChange('approvedByPosition', e.target.value)}
                placeholder="e.g. Campus Director"
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white"
              />
            </div>
          </div>
        </div>

        {/* Card 4: Institution & Campus Footer Info */}
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs space-y-4">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 dark:border-slate-800 pb-2.5">
            <Building className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            <span>4. Institution & Campus Details</span>
          </div>

          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                University / Institution Name
              </label>
              <input
                type="text"
                value={formData.agencyOrInstitution}
                onChange={(e) => handleChange('agencyOrInstitution', e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Campus Address
                </label>
                <input
                  type="text"
                  value={formData.campusAddress}
                  onChange={(e) => handleChange('campusAddress', e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Contact Number
                </label>
                <input
                  type="text"
                  value={formData.contactNumber}
                  onChange={(e) => handleChange('contactNumber', e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none text-slate-900 dark:text-white"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Live Signature Layout Preview */}
      <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 border-b border-slate-100 dark:border-slate-800 pb-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Live Signature Layout Preview (Page 2 of Accomplishment Report)
          </h3>
          <span className="text-[11px] text-slate-400 dark:text-slate-500 italic">
            Attachment pages remain clean and photo-dedicated
          </span>
        </div>

        <div className="p-6 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800 font-sans text-xs">
          <div className="grid grid-cols-2 gap-8 mb-12">
            <div>
              <p className="text-slate-500 dark:text-slate-400 mb-6">Prepared by:</p>
              <p className="font-bold text-slate-900 dark:text-white uppercase">
                {formData.employeeName || '[YOUR NAME]'}
              </p>
              <p className="text-slate-600 dark:text-slate-400">
                {formData.employeePosition || '[YOUR POSITION]'}
              </p>
            </div>

            <div>
              <p className="text-slate-500 dark:text-slate-400 mb-6">Verified by:</p>
              <p className="font-bold text-slate-900 dark:text-white uppercase">
                {formData.verifiedByName || '[IMMEDIATE HEAD NAME]'}
              </p>
              <p className="text-slate-600 dark:text-slate-400">
                {formData.verifiedByPosition || '[IMMEDIATE HEAD POSITION]'}
              </p>
            </div>
          </div>

          <div className="text-center">
            <p className="text-slate-500 dark:text-slate-400 mb-6">Approved by:</p>
            <p className="font-bold text-slate-900 dark:text-white uppercase">
              {formData.approvedByName || '[DIRECTOR NAME]'}
            </p>
            <p className="text-slate-600 dark:text-slate-400">
              {formData.approvedByPosition || '[DIRECTOR POSITION]'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
