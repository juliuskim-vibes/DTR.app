import React, { useState } from 'react';
import { X, User, ShieldCheck, Award, RotateCcw } from 'lucide-react';
import { InstitutionalMetadata } from '../types/dtr';

interface InstitutionalModalProps {
  metadata: InstitutionalMetadata;
  isOpen: boolean;
  onClose: () => void;
  onSave: (metadata: InstitutionalMetadata) => void;
}

export const InstitutionalModal: React.FC<InstitutionalModalProps> = ({
  metadata,
  isOpen,
  onClose,
  onSave,
}) => {
  if (!isOpen) return null;

  const [formData, setFormData] = useState<InstitutionalMetadata>(metadata);

  const handleChange = (field: keyof InstitutionalMetadata, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleResetToDefault = () => {
    setFormData({
      employeeName: 'JONATHAN K. LUCAGBO',
      employeePosition: 'Instructor I',
      verifiedByName: 'ENGR. REYNALDO T. VELEZ, M.ENG.',
      verifiedByPosition: 'Department Head, Information Technology',
      approvedByName: 'DR. NEMESIO G. LOAYON',
      approvedByPosition: 'Campus Director',
      agencyOrInstitution: 'North Eastern Mindanao State University',
      campusAddress: 'San Miguel, Surigao del Sur 8301',
      contactNumber: '09463014014',
      website: 'www.nemsu.edu.ph',
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 p-6 transition-colors"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Institutional Profile & Signatories
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              These details populate the official NEMSU Accomplishment Report header and Page 2 signatories.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-4 space-y-4">
          {/* Section 1: Employee */}
          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-slate-200 dark:border-slate-800 space-y-2.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200">
              <User className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              <span>Prepared by (Your Profile)</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Your Full Name
                </label>
                <input
                  type="text"
                  value={formData.employeeName}
                  onChange={(e) => handleChange('employeeName', e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg outline-none uppercase font-semibold text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Your Position / Designation
                </label>
                <input
                  type="text"
                  value={formData.employeePosition}
                  onChange={(e) => handleChange('employeePosition', e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg outline-none text-slate-900 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Immediate Head */}
          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-slate-200 dark:border-slate-800 space-y-2.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>Verified by (Immediate Head)</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Immediate Head Name
                </label>
                <input
                  type="text"
                  value={formData.verifiedByName}
                  onChange={(e) => handleChange('verifiedByName', e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg outline-none uppercase font-semibold text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Immediate Head Position
                </label>
                <input
                  type="text"
                  value={formData.verifiedByPosition}
                  onChange={(e) => handleChange('verifiedByPosition', e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg outline-none text-slate-900 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Section 3: Director */}
          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-slate-200 dark:border-slate-800 space-y-2.5">
            <div className="flex items-center gap-1.5 text-xs font-bold text-slate-800 dark:text-slate-200">
              <Award className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
              <span>Approved by (Campus Director)</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Director Name
                </label>
                <input
                  type="text"
                  value={formData.approvedByName}
                  onChange={(e) => handleChange('approvedByName', e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg outline-none uppercase font-semibold text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                  Director Position
                </label>
                <input
                  type="text"
                  value={formData.approvedByPosition}
                  onChange={(e) => handleChange('approvedByPosition', e.target.value)}
                  className="w-full px-3 py-1.5 text-xs bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg outline-none text-slate-900 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Institution Name & Campus */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                University / Institution
              </label>
              <input
                type="text"
                value={formData.agencyOrInstitution}
                onChange={(e) => handleChange('agencyOrInstitution', e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg outline-none text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Campus Address
              </label>
              <input
                type="text"
                value={formData.campusAddress}
                onChange={(e) => handleChange('campusAddress', e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg outline-none text-slate-900 dark:text-white"
              />
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-800">
          <button
            type="button"
            onClick={handleResetToDefault}
            className="text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 flex items-center gap-1"
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset NEMSU Defaults</span>
          </button>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 text-xs text-slate-600 dark:text-slate-300 hover:text-slate-900 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={() => {
                onSave(formData);
                onClose();
              }}
              className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-700 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-500 rounded-lg transition-colors"
            >
              Apply Settings
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
