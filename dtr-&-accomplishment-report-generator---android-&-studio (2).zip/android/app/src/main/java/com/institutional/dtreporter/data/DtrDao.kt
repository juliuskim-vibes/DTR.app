package com.institutional.dtreporter.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * Data Access Object (DAO) for Daily Time Record entries.
 * Provides reactive Flow observers and suspending CRUD operations for offline-first persistence.
 */
@Dao
interface DtrDao {

    /**
     * Inserts or updates a DTR entry. If an entry with the same date ("YYYY-MM-DD") exists,
     * it will be replaced atomically.
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(entry: DtrEntry)

    /**
     * Batch inserts or updates a list of entries (e.g., when initializing weekend placeholders).
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(entries: List<DtrEntry>)

    /**
     * Observes all DTR entries for a given month prefix (e.g., "2026-10-%").
     * Returns a reactive Kotlin Flow ordered chronologically by dayOfMonth.
     */
    @Query("SELECT * FROM dtr_entries WHERE date LIKE :monthPrefix ORDER BY dayOfMonth ASC")
    fun getEntriesForMonth(monthPrefix: String): Flow<List<DtrEntry>>

    /**
     * Synchronously/suspendingly queries a single DTR entry by its ISO date key.
     */
    @Query("SELECT * FROM dtr_entries WHERE date = :date LIMIT 1")
    suspend fun getEntryByDate(date: String): DtrEntry?

    /**
     * Deletes a specific DTR record.
     */
    @Delete
    suspend fun delete(entry: DtrEntry)

    /**
     * Clears all entries for a specific month.
     */
    @Query("DELETE FROM dtr_entries WHERE date LIKE :monthPrefix")
    suspend fun deleteMonth(monthPrefix: String)

    /**
     * Counts how many entries have attached photo proofs for a given month.
     */
    @Query("SELECT COUNT(*) FROM dtr_entries WHERE date LIKE :monthPrefix AND photoPath IS NOT NULL AND photoPath != ''")
    fun countPhotosForMonth(monthPrefix: String): Flow<Int>
}
