package com.institutional.dtreporter.util

import android.content.Context
import com.institutional.dtreporter.data.DtrEntry
import org.apache.poi.xwpf.usermodel.ParagraphAlignment
import org.apache.poi.xwpf.usermodel.TableRowAlign
import org.apache.poi.xwpf.usermodel.XWPFDocument
import org.apache.poi.xwpf.usermodel.XWPFParagraph
import org.apache.poi.xwpf.usermodel.XWPFRun
import org.apache.poi.xwpf.usermodel.XWPFTable
import org.apache.poi.xwpf.usermodel.XWPFTableCell
import org.apache.poi.xwpf.usermodel.XWPFTableRow
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STShd
import java.io.OutputStream
import java.math.BigInteger
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

data class ExportResult(
    val isSuccess: Boolean,
    val filePath: String? = null,
    val errorMessage: String? = null
)

/**
 * Institutional metadata with 3-tier signatories matching official NEMSU specifications:
 * - Prepared by: Employee (Name & Position)
 * - Verified by: Immediate Head (Name & Position)
 * - Approved by: Campus Director (Name & Position)
 */
data class InstitutionalMetadata(
    val employeeName: String = "JONATHAN K. LUCAGBO",
    val employeePosition: String = "Instructor I",
    val verifiedByName: String = "ENGR. REYNALDO T. VELEZ, M.ENG.",
    val verifiedByPosition: String = "Department Head, Information Technology",
    val approvedByName: String = "DR. NEMESIO G. LOAYON",
    val approvedByPosition: String = "Campus Director",
    val agencyOrInstitution: String = "North Eastern Mindanao State University",
    val campusAddress: String = "San Miguel, Surigao del Sur 8301",
    val contactNumber: String = "09463014014",
    val website: String = "www.nemsu.edu.ph"
)

object WordExporter {

    private const val FONT_ARIAL = "Arial"
    private const val HEADER_BLUE = "BDD7EE" // Official NEMSU soft blue table header tint

    fun exportMonthlyReport(
        context: Context,
        yearMonth: YearMonth,
        savedEntries: List<DtrEntry>,
        metadata: InstitutionalMetadata = InstitutionalMetadata()
    ): ExportResult {
        return try {
            val document = XWPFDocument()

            // Page Setup Margins (0.75 inch = 1080 twips)
            val docSect = document.document.body.sectPr ?: document.document.body.addNewSectPr()
            val pageMar = docSect.pgMar ?: docSect.addNewPgMar()
            pageMar.top = BigInteger.valueOf(1080)
            pageMar.bottom = BigInteger.valueOf(1080)
            pageMar.left = BigInteger.valueOf(1080)
            pageMar.right = BigInteger.valueOf(1080)

            // 1. Institution Header
            val instPara = document.createParagraph().apply {
                alignment = ParagraphAlignment.CENTER
                spacingAfter = 140
            }
            instPara.createRun().apply {
                fontFamily = FONT_ARIAL
                fontSize = 10
                setText("Republic of the Philippines")
                addBreak()
            }
            instPara.createRun().apply {
                fontFamily = FONT_ARIAL
                fontSize = 12
                isBold = true
                setText(metadata.agencyOrInstitution.uppercase(Locale.ROOT))
                addBreak()
                addBreak()
            }
            instPara.createRun().apply {
                fontFamily = FONT_ARIAL
                fontSize = 11
                isBold = true
                setText("ACCOMPLISHMENT REPORT")
                addBreak()
            }
            val monthYearTitle = yearMonth.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.US)).uppercase(Locale.ROOT)
            instPara.createRun().apply {
                fontFamily = FONT_ARIAL
                fontSize = 10
                isBold = true
                setText("MONTH OF $monthYearTitle")
            }

            // 2. Sub-Header: Name (Left) and Position (Right)
            val subTable = document.createTable(1, 2).apply {
                tableAlignment = TableRowAlign.CENTER
                width = 9600
            }
            val nameCell = subTable.getRow(0).getCell(0).apply { width = 5000 }
            nameCell.paragraphs[0].apply {
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    isBold = true
                    setText("Name: ")
                }
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    setText(metadata.employeeName.uppercase(Locale.ROOT))
                }
            }
            val posCell = subTable.getRow(0).getCell(1).apply { width = 4600 }
            posCell.paragraphs[0].apply {
                alignment = ParagraphAlignment.RIGHT
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    isBold = true
                    setText("Position: ")
                }
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    setText(metadata.employeePosition)
                }
            }

            document.createParagraph().apply { spacingAfter = 100 }

            // 3. Construct 3-Column Table (Date | Activities | Remarks)
            val table = document.createTable()
            table.tableAlignment = TableRowAlign.CENTER
            table.width = 9600

            // Header Row with soft blue shading
            val headerRow = table.getRow(0) ?: table.createRow()
            headerRow.isRepeatHeader = true
            val colWidths = intArrayOf(1000, 7000, 1600)
            val headerTitles = arrayOf("Date", "Activities", "Remarks")

            for (i in headerTitles.indices) {
                val cell = if (i == 0) headerRow.getCell(0) else headerRow.addNewTableCell()
                cell.width = colWidths[i]
                setCellShading(cell, HEADER_BLUE)

                val para = cell.paragraphs[0].apply {
                    alignment = ParagraphAlignment.CENTER
                    spacingBefore = 60
                    spacingAfter = 60
                }
                para.createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    isBold = true
                    setText(headerTitles[i])
                }
            }

            // Days 1..28/29/30/31
            val daysInMonth = yearMonth.lengthOfMonth()
            val entriesMap = savedEntries.associateBy { it.dayOfMonth }

            for (day in 1..daysInMonth) {
                val currentDate = LocalDate.of(yearMonth.year, yearMonth.month, day)
                val dayOfWeek = currentDate.dayOfWeek
                val isSat = dayOfWeek == DayOfWeek.SATURDAY
                val isSun = dayOfWeek == DayOfWeek.SUNDAY

                val savedEntry = entriesMap[day]
                var activitiesText = savedEntry?.activities?.trim().orEmpty()
                var remarksText = savedEntry?.remarks?.trim().orEmpty()

                if (isSat) {
                  activitiesText = "SATURDAY"
                  remarksText = ""
                } else if (isSun) {
                  activitiesText = "SUNDAY"
                  remarksText = ""
                } else if (savedEntry?.status == "Leave" && activitiesText.isEmpty()) {
                  activitiesText = "Leave"
                  remarksText = ""
                } else {
                  if (remarksText.isEmpty() && activitiesText.isNotEmpty()) {
                    remarksText = "Accomplished"
                  }
                }

                val row: XWPFTableRow = table.createRow()

                // Col 1: Date (Day number only, e.g. "1")
                val dateCell = row.getCell(0).apply { width = colWidths[0] }
                dateCell.paragraphs[0].apply {
                    alignment = ParagraphAlignment.CENTER
                    spacingBefore = 30
                    spacingAfter = 30
                    createRun().apply {
                        fontFamily = FONT_ARIAL
                        fontSize = 9
                        if (isSat || isSun) isBold = true
                        setText(day.toString())
                    }
                }

                // Col 2: Activities
                val actCell = row.getCell(1).apply { width = colWidths[1] }
                actCell.paragraphs[0].apply {
                    alignment = ParagraphAlignment.LEFT
                    spacingBefore = 30
                    spacingAfter = 30
                    createRun().apply {
                        fontFamily = FONT_ARIAL
                        fontSize = 9
                        if (isSat || isSun) isBold = true
                        setText(activitiesText)
                    }
                }

                // Col 3: Remarks
                val remCell = row.getCell(2).apply { width = colWidths[2] }
                remCell.paragraphs[0].apply {
                    alignment = ParagraphAlignment.CENTER
                    spacingBefore = 30
                    spacingAfter = 30
                    createRun().apply {
                        fontFamily = FONT_ARIAL
                        fontSize = 9
                        setText(remarksText)
                    }
                }
            }

            // 4. Institutional Footer on Page 1
            val footPara = document.createParagraph().apply {
                spacingBefore = 240
                spacingAfter = 200
            }
            footPara.createRun().apply {
                fontFamily = FONT_ARIAL
                fontSize = 8
                setText("${metadata.campusAddress} · ${metadata.contactNumber} · ${metadata.website}")
            }

            // 5. Page 2 Signatories (Prepared by & Verified by on top, Approved by centered below)
            val pageBreak = document.createParagraph().apply {
                isPageBreak = true
                spacingBefore = 200
            }

            // Top Row: Prepared by & Verified by
            val topSignTable = document.createTable(1, 2).apply {
                tableAlignment = TableRowAlign.CENTER
                width = 9600
            }

            // Prepared by
            val prepCell = topSignTable.getRow(0).getCell(0).apply { width = 4800 }
            prepCell.paragraphs[0].apply {
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    setText("Prepared by:\n\n\n\n")
                }
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    isBold = true
                    setText(metadata.employeeName.uppercase(Locale.ROOT))
                    addBreak()
                }
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 9
                    setText(metadata.employeePosition)
                }
            }

            // Verified by (Immediate Head)
            val verCell = topSignTable.getRow(0).getCell(1).apply { width = 4800 }
            verCell.paragraphs[0].apply {
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    setText("Verified by:\n\n\n\n")
                }
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    isBold = true
                    setText(metadata.verifiedByName.uppercase(Locale.ROOT))
                    addBreak()
                }
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 9
                    setText(metadata.verifiedByPosition)
                }
            }

            // Approved by (Center Bottom)
            document.createParagraph().apply { spacingBefore = 400 }

            val appTable = document.createTable(1, 1).apply {
                tableAlignment = TableRowAlign.CENTER
                width = 9600
            }
            val appCell = appTable.getRow(0).getCell(0).apply { width = 9600 }
            appCell.paragraphs[0].apply {
                alignment = ParagraphAlignment.CENTER
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    setText("Approved by:\n\n\n\n")
                }
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    isBold = true
                    setText(metadata.approvedByName.uppercase(Locale.ROOT))
                    addBreak()
                }
                createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 9
                    setText(metadata.approvedByPosition)
                }
            }

            // 6. Annex A: Means of Verification (MOV) / Photographic Evidence with Date Tags
            val photoEntries = savedEntries.filter { !it.photoPath.isNullOrBlank() && java.io.File(it.photoPath).exists() }
            if (photoEntries.isNotEmpty()) {
                val annexHeader = document.createParagraph().apply {
                    isPageBreak = true
                    alignment = ParagraphAlignment.CENTER
                    spacingBefore = 200
                    spacingAfter = 140
                }
                annexHeader.createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 11
                    isBold = true
                    setText("ANNEX A: MEANS OF VERIFICATION (MOV) / PHOTOGRAPHIC EVIDENCE")
                    addBreak()
                }
                annexHeader.createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 10
                    isBold = true
                    setText("ATTACHED PROOF OF DAILY ACCOMPLISHMENTS — MONTH OF $monthYearTitle")
                    addBreak()
                }
                annexHeader.createRun().apply {
                    fontFamily = FONT_ARIAL
                    fontSize = 9
                    setText("Personnel: ${metadata.employeeName.uppercase(Locale.ROOT)} · ${metadata.employeePosition}")
                }

                for (entry in photoEntries) {
                    val photoFile = java.io.File(entry.photoPath!!)
                    val tagPara = document.createParagraph().apply {
                        alignment = ParagraphAlignment.LEFT
                        spacingBefore = 180
                        spacingAfter = 60
                    }
                    tagPara.createRun().apply {
                        fontFamily = FONT_ARIAL
                        fontSize = 10
                        isBold = true
                        setText("DATE TAG: ${entry.date} (Day ${entry.dayOfMonth})")
                        addBreak()
                    }
                    tagPara.createRun().apply {
                        fontFamily = FONT_ARIAL
                        fontSize = 9
                        setText("Accomplishment: ${if (entry.activities.isNotBlank()) entry.activities else "Official duty logged"} [Status: ${entry.status}]")
                    }

                    // Embed Picture via Apache POI
                    val imgPara = document.createParagraph().apply {
                        alignment = ParagraphAlignment.CENTER
                        spacingAfter = 200
                    }
                    try {
                        java.io.FileInputStream(photoFile).use { fis ->
                            imgPara.createRun().addPicture(
                                fis,
                                org.apache.poi.xwpf.usermodel.Document.PICTURE_TYPE_JPEG,
                                photoFile.name,
                                org.apache.poi.util.Units.toEMU(420.0),
                                org.apache.poi.util.Units.toEMU(260.0)
                            )
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }

            // 7. Write out to public Downloads folder
            val fileMonthStr = yearMonth.format(DateTimeFormatter.ofPattern("yyyy_MM", Locale.US))
            val sanitizedName = metadata.employeeName.replace("\\s+".toRegex(), "_")
            val fileName = "DTR_Accomplishment_Report_${sanitizedName}_${fileMonthStr}.docx"

            val (outputStream, savedPath) = FileUtil.openDownloadsOutputStream(context, fileName)
            if (outputStream == null) {
                return ExportResult(false, errorMessage = "Failed to obtain output stream for Downloads.")
            }

            outputStream.use { stream ->
                document.write(stream)
                stream.flush()
            }
            document.close()

            ExportResult(true, filePath = savedPath ?: "Downloads/$fileName")
        } catch (e: Exception) {
            e.printStackTrace()
            ExportResult(false, errorMessage = e.localizedMessage)
        }
    }

    private fun setCellShading(cell: XWPFTableCell, hexColor: String) {
        val tcPr = cell.ctTc.tcPr ?: cell.ctTc.addNewTcPr()
        val ctShd = tcPr.shd ?: tcPr.addNewShd()
        ctShd.setVal(STShd.CLEAR)
        ctShd.setColor("auto")
        ctShd.setFill(hexColor)
    }
}
