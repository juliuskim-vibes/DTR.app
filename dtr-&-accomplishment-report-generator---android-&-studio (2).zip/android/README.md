# Daily Time Record (DTR) & Accomplishment Report Generator
### Offline-First Android Application Architecture

Built with **Kotlin**, **Jetpack Compose (Material 3)**, **Room Database (2.6.1)**, **Coil (2.7.0)**, and **Apache POI (5.2.5)**.

---

## 🏛 Institutional Requirements Covered

1. **Offline Persistence with Room Database**:
   - `DtrEntry` entity keyed by ISO date string (`YYYY-MM-DD`).
   - Chronological query by month prefix (e.g. `2026-10-%`).
   - Reactive Kotlin `Flow` stream updates UI instantly upon database changes.
   - Atomic replacement on conflict (`OnConflictStrategy.REPLACE`).

2. **Camera & Image Proof Attachment**:
   - Camera launched using modern `ActivityResultContracts.TakePicture()`.
   - Temporary capture buffer generated securely via AndroidX `FileProvider` (`file_paths.xml`).
   - Captured photos compressed and copied to internal app storage (`context.filesDir/photos/`) to preserve privacy and avoid external storage permissions.
   - Thumbnail previews loaded via Coil `AsyncImage`.

3. **Auto Weekend Tagging**:
   - `java.time.LocalDate` / `YearMonth` evaluates every day from 1 to the end of the month (28/29/30/31).
   - Unedited Saturdays and Sundays automatically receive `"SATURDAY"` and `"SUNDAY"` remarks.
   - Batch auto-tag button in TopAppBar allows one-tap institutional compliance.

4. **Apache POI (.docx) Exporting**:
   - Header: `"ACCOMPLISHMENT REPORT / MONTH OF [MONTH YEAR]"` (Centered, Bold, Arial 12pt).
   - 3-Column official table: `Date` | `Activities` | `Remarks`.
   - Cell widths calibrated in twips for standard Letter / A4 paper.
   - Soft shading (`#E2E8F0`) on header cells and light tint on weekends for scanning clarity.
   - Institutional sign-off section with Prepared by & Approved by lines.
   - Saved directly to device's public `Downloads/` directory using modern Scoped Storage `MediaStore` (Android 10+) with legacy fallback.

5. **Gradle Packaging Configuration**:
   - `packaging { resources { excludes += ... } }` in `build.gradle.kts` handles Apache POI's duplicate `META-INF` licenses, notices, and XML schemas to prevent `DuplicateFileException`.

---

## 📁 Source File Inventory

- `android/app/build.gradle.kts`: Module build configuration with Compose, Room, Coil, Apache POI 5.2.5.
- `android/app/src/main/AndroidManifest.xml`: Permissions, single Activity, and FileProvider declaration.
- `android/app/src/main/res/xml/file_paths.xml`: FileProvider path mapping.
- `android/app/src/main/java/com/institutional/dtreporter/data/DtrEntry.kt`: Room Entity.
- `android/app/src/main/java/com/institutional/dtreporter/data/DtrDao.kt`: Room DAO interface.
- `android/app/src/main/java/com/institutional/dtreporter/data/AppDatabase.kt`: Room Database Singleton.
- `android/app/src/main/java/com/institutional/dtreporter/util/FileUtil.kt`: Camera & internal storage utilities.
- `android/app/src/main/java/com/institutional/dtreporter/util/WordExporter.kt`: Apache POI document builder.
- `android/app/src/main/java/com/institutional/dtreporter/ui/MainViewModel.kt`: State orchestration.
- `android/app/src/main/java/com/institutional/dtreporter/ui/HomeScreen.kt`: Material 3 monthly UI.
- `android/app/src/main/java/com/institutional/dtreporter/ui/DailyEntryDialog.kt`: Log editor & camera dialog.
- `android/app/src/main/java/com/institutional/dtreporter/MainActivity.kt`: Compose Activity host.
